呂昀修 60947045s 資工碩三

mid01:
	先去檢查是否為矩形，P1P2的slope是否等於P4P3的slope，以及P1P4的slope是否等於P2P3的slope。
	要平分矩形面積，只要點P過矩形中心點即可。
	中心點(xc, yc) = ((x1+x3)/2, (y1+y3)/2)，一定會與((x2+x4)/2, (y2+y4)/2)相等。
	用(x, y)及(xc, yc)算直線方程即可。
mid02:
	先把值轉成32bits的signed number。然後依序紀錄每個bit，最後去判斷是否為palindrome
mid03:
	如結果
mid04:
	如結果
mid05:
	

bonus:
	good
vote:
	up to you
