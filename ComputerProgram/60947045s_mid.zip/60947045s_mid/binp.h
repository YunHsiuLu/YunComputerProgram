#ifndef __binp_h
#define __binp_h
#include <stdint.h>
int32_t Int2Bin(int32_t x);
int32_t isBinaryPalindrome(int32_t x);

#endif
