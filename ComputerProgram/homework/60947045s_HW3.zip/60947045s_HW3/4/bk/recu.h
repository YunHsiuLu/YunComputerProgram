#ifndef __recu_h
#define __recu_h

#include <stdint.h>
extern int32_t step;
void Hanoi_recu(int8_t n, int8_t *arr, int8_t A, int8_t B, int8_t C);

#endif
