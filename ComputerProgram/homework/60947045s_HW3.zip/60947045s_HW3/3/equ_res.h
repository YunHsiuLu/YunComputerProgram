#ifndef __equ_res_h
#define __equ_res_h

#include <stdint.h>
double result(int32_t ohm, int32_t num);

#endif
