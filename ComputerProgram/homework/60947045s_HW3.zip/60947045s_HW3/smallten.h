#ifndef SMALLTEN_H
#define SMALLTEN_H
#include <stdio.h>
#include "logic.h"

void communicate();

#endif
