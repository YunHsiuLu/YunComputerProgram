#ifndef __mystddev_h
#define __mystddev_h

#include <stdint.h>
double get_stddev(int32_t number);

#endif
