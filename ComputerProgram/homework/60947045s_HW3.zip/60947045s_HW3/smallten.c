#include "smallten.h"
int x = 0, y = 0;

void communicate() {
	printf("Please enter the first number (A) in binary: ");
	scanf("%d", &x);
	printf("Please enter the second number (B) in binary: ");
	scanf("%d", &y);

}
