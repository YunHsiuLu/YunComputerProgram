#include "smallten.h"

void communicate() {
	printf("In communicate......\n");
	printf("Out communicate.....\n");
}
